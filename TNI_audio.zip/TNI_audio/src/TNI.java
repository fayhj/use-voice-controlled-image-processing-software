
import edu.cmu.sphinx.frontend.util.Microphone;
import edu.cmu.sphinx.recognizer.Recognizer;
import edu.cmu.sphinx.result.Result;
import edu.cmu.sphinx.util.props.ConfigurationManager;
import java.io.File;
import java.io.IOException;

import ij.ImagePlus;
import ij.io.Opener;
import ij.process.ImageConverter;
import ij.process.ImageProcessor;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Horace
 */
public class TNI extends javax.swing.JDialog {

    String path="rien";
    String path2, path3 , path4, path5 , path6, path7;
    int alpha, dimension_moyen, dimension_mediant , seuil;
    double F=3.0;
    double sigma_x=4, sigma_y=16;
    /**
     * Creates new form TNI
     */
    public TNI(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }

    public void rotate(){
                // TODO add your handling code here:
        int angle;
        angle = alpha;
        double cos = Math.cos(Math.PI*angle/180.);
        double sin = Math.sin(Math.PI*angle/180.);
        System.out.print(path);
        File originalImage=new File(path);
        BufferedImage im = null;
        try {
            im= ImageIO.read(originalImage);
        } catch (IOException ex) {
            Logger.getLogger(TNI.class.getName()).log(Level.SEVERE, null, ex);
        }

        int W = im.getWidth(), H = im.getHeight();

        int Xc = W/2, Yc = H/2;

        int W2 = (int) (W*Math.abs(cos)+H*Math.abs(sin));
        int H2 = (int) (W*Math.abs(sin)+H*Math.abs(cos));

        int Xc2 = W2/2, Yc2 = H2/2;
        Color l=new Color(0,0,0);
        BufferedImage  imro = new BufferedImage(W2,H2,BufferedImage.TYPE_INT_ARGB);

        for (int y2=0;y2<H2;y2++) {
            for (int x2=0;x2<W2;x2++) {
                imro.setRGB(x2, y2, l.getRGB());
            }
        }
        for (int y2=0;y2<H2;y2++) {
            for (int x2=0;x2<W2;x2++) {

                int x = (int) Math.round( Xc + (x2-Xc2)*cos - (y2-Yc2)*sin );
                int y = (int) Math.round(Yc + (x2-Xc2)*sin + (y2-Yc2)*cos );

                if (x>=0 && x<W && y>=0 && y<H && imro.getRGB(x2, y2) == l.getRGB()) imro.setRGB(x2, y2, im.getRGB(x,y));
               
            }
        }

        String pathf = "C:\\Users\\fayhj\\Pictures\\arote.png";
        if(rotate_image_name.getText().toString() != "Image rotate name"){
            pathf= "C:\\Users\\fayhj\\Pictures\\" +  rotate_image_name.getText().toString() +".png";}

            try {
                ImageIO.write(imro, "png", new File(pathf));
            } catch (IOException ex) {
                Logger.getLogger(TNI.class.getName()).log(Level.SEVERE, null, ex);
            }
            Opener open= new Opener();
            ImagePlus imp = open.openImage(pathf);
            new ImageConverter(imp).convertToGray8();

            ImageIcon i2= new ImageIcon( imp.getImage()) ;
            rotation_label2.setIcon(i2);
    }
    
    public void garborFilter(){
        GaborFilter(path2);
    }
    public void filtreMoyen(){
        filtre_moyenneur(path3, dimension_moyen);
    }
    public void filtreMedian(){
        filtre_median(path4, dimension_mediant);
    }
    public void segmentationSeuilllageSimple(){
        ImagePlus originalImage= new ImagePlus(path5);
        new ImageConverter(originalImage).convertToGray8();
        
        int width=originalImage.getWidth(),
            height=originalImage.getHeight();
        ImageProcessor ip0= originalImage.getProcessor();
        
        ImagePlus imaf = originalImage.duplicate();
        imaf.setProcessor(segmentationSeuillage(ip0, width, height)); //appel de la fonction segmentationSeuillage pour appliquer 
        //le seuilage
        ImageIcon i2= new ImageIcon( imaf.getImage()) ;
        //originalImage.show();
        seg_seuillage2.setIcon(i2);
    }
    public void segmentationSeuilllageAdaptatif(){
                ImagePlus originalImage= new ImagePlus(path5);
        new ImageConverter(originalImage).convertToGray8();
        //application de la segmentation par seuillage 3x3
        int width=originalImage.getWidth(),
            height=originalImage.getHeight();
        ImageProcessor ip0= originalImage.getProcessor();
        ImageProcessor ip = ip0.duplicate();
        
        ImageProcessor ip0_moyenné = functionFiltreMoyenneur(ip0, width, height, 3); //application du filtre moyenneur 3x3
        //application de la fonction de segmentation apres avoir appliquer mle filtre moyen 3x3
        for ( int w = 0 ; w< width ; w++)
        {
            for(int h =0 ; h< height ; h++)
            {
                if(ip0.get( w ,h) < ip0_moyenné.get( w ,h) ) ip.set(w, h, 0);
                else  ip.set(w, h, 255);
            }
        }
        ImagePlus imaf = originalImage.duplicate();
        imaf.setProcessor(ip);
        ImageIcon i2= new ImageIcon( imaf.getImage()) ;
        //originalImage.show();
        seg_seuillage2.setIcon(i2);
    }
    public void masqueSobelX(){
         int[][] masque= { {-1,0,1},{-2,0,2},{-1,0,1} };//definition de l matrice du masque sobel suivant X
        function_applique_masque(masque);//appel de la fonction pour apliquer le masque
    }
    public void masqueSobelY(){
        int[][] masque= { {-1,-2,-1},{0,0,0},{1,2,1} };//matrice masque de sobel suivant Y
        function_applique_masque(masque);
    }
    public void seuillageLaplacien(){
         ImagePlus originalImage= new ImagePlus(path7);
        new ImageConverter(originalImage).convertToGray8();
         int[][] masque= { {0,1,0},{1,-4,1},{0,1,0} };
         
        int width=originalImage.getWidth(),
            height=originalImage.getHeight();
        ImageProcessor ip0= originalImage.getProcessor();
        ImageProcessor ip = ip0.duplicate();
        //application du masque
        for ( int w = 1 ; w< width-1 ; w++)
        {
            for(int h =1 ; h< height-1 ; h++)
            {
                int r=0;
                for ( int i = -1 ; i<= 1 ; i++)
                {
                    for(int j =-1 ; j<= 1 ; j++)
                    {
                        r += masque[i+1][j+1]* ip0.get( w+i ,h+j) ; 
                    }
                }
                 ip.set(w, h, Math.abs(r));
            }
        }
        
        ImagePlus imaf = originalImage.duplicate();
        imaf.setProcessor(  ip  );
        ImageIcon i2= new ImageIcon( imaf.getImage()) ;
        //originalImage.show();
        laplacien2.setIcon(i2);
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        rotate_label1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        rotation_label1 = new javax.swing.JLabel();
        rotate_label2 = new javax.swing.JPanel();
        rotion_panel2 = new javax.swing.JScrollPane();
        rotation_label2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jSpinner1 = new javax.swing.JSpinner();
        jButton2 = new javax.swing.JButton();
        rotate_image_name = new javax.swing.JTextField();
        jButton15 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        garbor_filter_label2 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        filtre_moyen_label2 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jSpinner2 = new javax.swing.JSpinner();
        jLabel2 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jScrollPane9 = new javax.swing.JScrollPane();
        seg_seuillage2 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        seuilSpinner = new javax.swing.JSpinner();
        jLabel4 = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        jPanel14 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jScrollPane11 = new javax.swing.JScrollPane();
        gradiant2 = new javax.swing.JLabel();
        sobel_x = new javax.swing.JButton();
        sobel_y = new javax.swing.JButton();
        jPanel18 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jScrollPane12 = new javax.swing.JScrollPane();
        laplacien2 = new javax.swing.JLabel();
        jButton14 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        filtre_medien_label2 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jSpinner3 = new javax.swing.JSpinner();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jScrollPane1.setViewportView(rotation_label1);

        javax.swing.GroupLayout rotate_label1Layout = new javax.swing.GroupLayout(rotate_label1);
        rotate_label1.setLayout(rotate_label1Layout);
        rotate_label1Layout.setHorizontalGroup(
            rotate_label1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rotate_label1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 272, Short.MAX_VALUE)
                .addContainerGap())
        );
        rotate_label1Layout.setVerticalGroup(
            rotate_label1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, rotate_label1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );

        rotion_panel2.setViewportView(rotation_label2);

        javax.swing.GroupLayout rotate_label2Layout = new javax.swing.GroupLayout(rotate_label2);
        rotate_label2.setLayout(rotate_label2Layout);
        rotate_label2Layout.setHorizontalGroup(
            rotate_label2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rotate_label2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(rotion_panel2)
                .addContainerGap())
        );
        rotate_label2Layout.setVerticalGroup(
            rotate_label2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rotate_label2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(rotion_panel2)
                .addContainerGap())
        );

        jButton1.setText("Open Image");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel1.setText("Angle de rotation : ");

        jSpinner1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSpinner1StateChanged(evt);
            }
        });

        jButton2.setText("Rotation totale");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        rotate_image_name.setText("Image rotate name");
        rotate_image_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rotate_image_nameActionPerformed(evt);
            }
        });

        jButton15.setText("Rotation fixe");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rotate_image_name, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(rotate_label1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 129, Short.MAX_VALUE))
                    .addComponent(rotate_label2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rotate_label2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(rotate_label1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton2)
                            .addComponent(jButton15))
                        .addComponent(rotate_image_name, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addContainerGap())))
        );

        jTabbedPane1.addTab("Simple rotation", jPanel1);

        jScrollPane3.setViewportView(garbor_filter_label2);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 369, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 405, Short.MAX_VALUE)
                .addContainerGap())
        );

        jButton8.setText("Appliquer filtre");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(223, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(417, 417, 417))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(281, 281, 281))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton8)
                .addGap(22, 22, 22))
        );

        jTabbedPane1.addTab("Garbor filter", jPanel2);

        jScrollPane5.setViewportView(filtre_moyen_label2);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 575, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 421, Short.MAX_VALUE)
                .addContainerGap())
        );

        jButton6.setText("Appliquer filtre");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jSpinner2.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSpinner2StateChanged(evt);
            }
        });

        jLabel2.setText("Dimension :");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(234, 234, 234)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSpinner2, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(71, Short.MAX_VALUE)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(227, 227, 227))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton6)
                    .addComponent(jSpinner2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)))
        );

        jTabbedPane1.addTab("filtre moyen", jPanel3);

        jScrollPane9.setViewportView(seg_seuillage2);

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 500, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 377, Short.MAX_VALUE)
                .addContainerGap())
        );

        jButton10.setText("Seuillage simple");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        seuilSpinner.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                seuilSpinnerStateChanged(evt);
            }
        });

        jLabel4.setText("Seuil :");

        jButton11.setText("Seuillage adaptatif  3x3");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(157, 157, 157)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(seuilSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(86, 86, 86)
                        .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton11)))
                .addContainerGap(216, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton10)
                    .addComponent(seuilSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jButton11))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Segmentation par seuillage", jPanel11);

        jScrollPane11.setViewportView(gradiant2);

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane11, javax.swing.GroupLayout.DEFAULT_SIZE, 577, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane11, javax.swing.GroupLayout.DEFAULT_SIZE, 315, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                .addContainerGap(117, Short.MAX_VALUE)
                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        sobel_x.setText("Masque sobel selon X");
        sobel_x.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sobel_xActionPerformed(evt);
            }
        });

        sobel_y.setText("Masque sobel selon Y");
        sobel_y.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sobel_yActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGap(266, 266, 266)
                .addComponent(sobel_x)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(sobel_y)
                .addContainerGap(347, Short.MAX_VALUE))
            .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel14Layout.createSequentialGroup()
                    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 169, Short.MAX_VALUE)))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addContainerGap(428, Short.MAX_VALUE)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sobel_x)
                    .addComponent(sobel_y))
                .addGap(32, 32, 32))
            .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel14Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(113, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("Seuillage par gradiant", jPanel14);

        laplacien2.setText("jLabel6");
        jScrollPane12.setViewportView(laplacien2);

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane12, javax.swing.GroupLayout.DEFAULT_SIZE, 687, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane12, javax.swing.GroupLayout.DEFAULT_SIZE, 371, Short.MAX_VALUE)
                .addContainerGap())
        );

        jButton14.setText("Apply");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap(84, Short.MAX_VALUE)
                .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(102, 102, 102))
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addGap(406, 406, 406)
                .addComponent(jButton14)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton14)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Seuillage Laplacien", jPanel18);

        jScrollPane6.setViewportView(filtre_medien_label2);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(89, Short.MAX_VALUE)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 499, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 395, Short.MAX_VALUE)
        );

        jButton4.setText("Appliquer filtre mediant");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jSpinner3.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSpinner3StateChanged(evt);
            }
        });

        jLabel3.setText("Dimension :");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(156, 156, 156)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSpinner3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(267, 267, 267))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(130, 130, 130)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(146, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jLabel3)
                    .addComponent(jSpinner3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22))
        );

        jTabbedPane1.addTab("filtre médiant", jPanel4);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        File repertoireCourant = null;
        try{
            repertoireCourant = new File(".").getCanonicalFile();
        }catch(IOException e){};
        JFileChooser dialogue = new JFileChooser(repertoireCourant);
        dialogue.showOpenDialog(null);
        String b= "\\"+"\\";
        String a="\\";
        path = dialogue.getSelectedFile().getAbsolutePath().replace(a,b);
        path2= path;
        path3= path;
        path4= path;
        path5= path;
        path6= path;
        path7= path;
        ImageIcon icon = new ImageIcon(path);
        rotation_label1.setIcon(icon);

        ImagePlus image= new ImagePlus(path3);
        new ImageConverter(image).convertToGray8();
        ImageIcon icon2 = new ImageIcon( image.getImage()) ;
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jSpinner1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSpinner1StateChanged
        // TODO add your handling code here:
        String v= jSpinner1.getValue().toString();
        alpha = Integer.valueOf(v).intValue();

    }//GEN-LAST:event_jSpinner1StateChanged

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        rotate();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void rotate_image_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rotate_image_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rotate_image_nameActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        garborFilter();
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        filtreMoyen();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jSpinner2StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSpinner2StateChanged
        // Recuperation de la valeur du spinner

        String s= jSpinner2.getValue().toString();
        dimension_moyen = Integer.valueOf(s).intValue();
    }//GEN-LAST:event_jSpinner2StateChanged

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // 
        filtreMedian();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jSpinner3StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSpinner3StateChanged
        // recuperation de la dimension dans le spinner
        String s = jSpinner3.getValue().toString();
        dimension_mediant = Integer.valueOf(s).intValue();
    }//GEN-LAST:event_jSpinner3StateChanged

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        segmentationSeuilllageSimple();
    }//GEN-LAST:event_jButton10ActionPerformed

    private void seuilSpinnerStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_seuilSpinnerStateChanged
        String s = seuilSpinner.getValue().toString();
        seuil = Integer.valueOf(s).intValue();
    }//GEN-LAST:event_seuilSpinnerStateChanged

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        segmentationSeuilllageAdaptatif();
    }//GEN-LAST:event_jButton11ActionPerformed

    private void sobel_xActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sobel_xActionPerformed
        
       masqueSobelX();
    }//GEN-LAST:event_sobel_xActionPerformed

    public void function_applique_masque(int[][] masque)
    { 
        //fonction charge d'appliquer les masques de sobel
        ImagePlus originalImage= new ImagePlus(path6);
        new ImageConverter(originalImage).convertToGray8();
        
        int width=originalImage.getWidth(),
            height=originalImage.getHeight();
        ImageProcessor ip0= originalImage.getProcessor();
        ImageProcessor ip = ip0.duplicate();
        for ( int w = 1 ; w< width-1 ; w++)
        {
            for(int h =1 ; h< height-1 ; h++)
            {
                int r=0;
                for ( int i = -1 ; i<= 1 ; i++)
                {
                    for(int j =-1 ; j<= 1 ; j++)
                    {
                        r += masque[i+1][j+1]* ip0.get( w+i ,h+j) ; 
                    }
                }
                 ip.set(w, h, Math.abs(r));
            }
        }
        
        ImagePlus imaf = originalImage.duplicate();
        imaf.setProcessor(  ip  );
        ImageIcon i2= new ImageIcon( imaf.getImage()) ;
        //originalImage.show();
        gradiant2.setIcon(i2);
    }
    
    private void sobel_yActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sobel_yActionPerformed
        masqueSobelY();
    }//GEN-LAST:event_sobel_yActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        seuillageLaplacien();
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        int angle;
        angle = alpha;
        double cos = Math.cos(Math.PI*angle/180.);
        double sin = Math.sin(Math.PI*angle/180.);

        File originalImage=new File(path);
        BufferedImage im = null;
        try {
            im= ImageIO.read(originalImage);
        } catch (IOException ex) {
            Logger.getLogger(TNI.class.getName()).log(Level.SEVERE, null, ex);
        }

        int W = im.getWidth(), H = im.getHeight();

        int Xc = W/2, Yc = H/2;

        int W2 = W;
        int H2 = H;

        int Xc2 = W2/2, Yc2 = H2/2;
        Color l=new Color(0,0,0);
        BufferedImage  imro = new BufferedImage(W2,H2,BufferedImage.TYPE_INT_ARGB);

        for (int y2=0;y2<H2;y2++) {
            for (int x2=0;x2<W2;x2++) {
                imro.setRGB(x2, y2, l.getRGB());
            }
        }
        for (int y2=0;y2<H2;y2++) {
            for (int x2=0;x2<W2;x2++) {

                int x = (int) Math.round( Xc + (x2-Xc2)*cos - (y2-Yc2)*sin );
                int y = (int) Math.round(Yc + (x2-Xc2)*sin + (y2-Yc2)*cos );

                if (x>=0 && x<W && y>=0 && y<H && imro.getRGB(x2, y2) == l.getRGB()) imro.setRGB(x2, y2, im.getRGB(x,y));
               
            }
        }

        String pathf = "C:\\Users\\fayhj\\Pictures\\arote.png";
        if(rotate_image_name.getText().toString() != "Image rotate name"){
            pathf= "C:\\Users\\fayhj\\Pictures\\" +  rotate_image_name.getText().toString() +".png";}

            try {
                ImageIO.write(imro, "png", new File(pathf));
            } catch (IOException ex) {
                Logger.getLogger(TNI.class.getName()).log(Level.SEVERE, null, ex);
            }
            Opener open= new Opener();
            ImagePlus imp = open.openImage(pathf);
            new ImageConverter(imp).convertToGray8();

            ImageIcon i2= new ImageIcon( imp.getImage()) ;
            rotation_label2.setIcon(i2);
    }//GEN-LAST:event_jButton15ActionPerformed

    
    
    public void  GaborFilter( String chemin){
        //image_filtrée=  mon_image;
        //Opener open=new Opener();
        ImagePlus originalImage= new ImagePlus(chemin);
        new ImageConverter(originalImage).convertToGray8();
        
        int width=originalImage.getWidth(),
            height=originalImage.getHeight();
        ImageProcessor ip0= originalImage.getProcessor();
        ImageProcessor ip=ip0.duplicate();
        
        double sigma_x2=sigma_x*sigma_x;
        double sigma_y2=sigma_y*sigma_y;
        
        
        int filterSizeX=19,
            filterSizeY=19;
        
        int middleX= (int) Math.round((filterSizeX)/2);
        int middleY= (int) Math.round((filterSizeY)/2);
        
        double theta=Math.PI/(double)6;
        //double theta= 0.5;
        
        for(int w = middleX; w< width- middleX ; w++  )
        {
            for( int h=middleY ; h< height-middleY ; h++)
            {
                    double valeur2=0;
                    for(int x=-middleX;x<middleX;x++)
                    {
                        //int valeur=0;
                        for(int y=-middleY;y<middleY;y++)
                        {
                            double xPrime= (double)x * Math.cos(theta)+ (double)y * Math.sin(theta);
                            double yPrime= (double)y * Math.cos(theta)- (double)x * Math.sin(theta);

                            double a= 1.0/(2.0*Math.PI*sigma_x*sigma_y) * Math.exp(-0.5 *(xPrime*xPrime/sigma_x2 + yPrime*yPrime/sigma_y2));
                            double c=a * Math.cos(2.0 * Math.PI *(F *xPrime)/filterSizeX);
                            valeur2 += ( c *  ip0.get(w -x, h-y) );
                        }
                    }
                    ip.set(w, h, (int)valeur2);
                    //valeur2=0;
            }
        }
        
        ImagePlus imaf = originalImage.duplicate();
        imaf.setProcessor(ip);
        ImageIcon i2= new ImageIcon( imaf.getImage()) ;
        //originalImage.show();
        garbor_filter_label2.setIcon(i2);
    }
    
    public void filtre_moyenneur(String chemin , int dimension)
    {
        ImagePlus originalImage= new ImagePlus(chemin);
        new ImageConverter(originalImage).convertToGray8();
        
        int width=originalImage.getWidth(),
            height=originalImage.getHeight();
        ImageProcessor ip0= originalImage.getProcessor();
        
        
        ImagePlus imaf = originalImage.duplicate();
        imaf.setProcessor(  functionFiltreMoyenneur(ip0, width, height, dimension) );
        ImageIcon i2= new ImageIcon( imaf.getImage()) ;
        //originalImage.show();
        filtre_moyen_label2.setIcon(i2);
    }
    public ImageProcessor functionFiltreMoyenneur( ImageProcessor ip0 ,int width ,int height, int dimension)
    {//fonction realisant le filtrage moyenneur
        ImageProcessor ip = ip0.duplicate();
        for ( int w = 0 ; w< width ; w++)
        {
            for(int h =0 ; h< height ; h++)
            {
                double value=0;
                int c=0;
                for( int u= -(dimension-1)/2 ; u<= (dimension-1)/2 ; u++ )
                {
                    for( int v= -(dimension-1)/2 ; v<= (dimension-1)/2 ; v++ )
                    {
                        int a=w+u, b= h+v;
                        if ( a<width && a>=0 && b< height && b >=0 ){ value += (ip0.get( a ,b) ); c++;}
                    }
                }
                int val = (int)(value/c);
                ip.set(w, h, val);
            }
        }
        return ip;
    }
    
    public void filtre_median( String chemin ,int dimension)
    {
        ImagePlus originalImage= new ImagePlus(chemin);
        new ImageConverter(originalImage).convertToGray8();
        
        int width=originalImage.getWidth(),
            height=originalImage.getHeight();
        ImageProcessor ip0= originalImage.getProcessor();
        ImageProcessor ip = ip0.duplicate();
        
        for ( int w = 0 ; w< width ; w++)
        {
            for(int h =0 ; h< height ; h++)
            {
                // on recupere tous les pixels du voisinnage
                if ( (w-(dimension-1)/2) >=0 && (w+(dimension-1)/2)<width && (h-(dimension-1)/2) >=0 && (h+(dimension-1)/2)<height   )
                {
                    int mediane=0, i=0;
                    int[] liste_pixels = new int[dimension*dimension];
                    for( int u= -(dimension-1)/2 ; u<= (dimension-1)/2 ; u++ )
                    {
                        for( int v= -(dimension-1)/2 ; v<= (dimension-1)/2 ; v++ )
                        {
                            int a=w+u, b= h+v;
                            liste_pixels[i] = ip0.get( a ,b); i++;
                        }
                    }
                    //rangement par ordre croissant
                    int[] liste_pixels_ordonnes_par_ordre_croissant = new int[dimension*dimension];
                    int infini =1000000, min, indice=0;
                    for(int k = 0 ; k< dimension*dimension ; k++)
                    {
                        min=infini;
                        for(int j = 0 ; j< dimension*dimension ; j++ )
                        {
                            if( liste_pixels[j] < min ) {min = liste_pixels[j];  indice= j;}
                        }
                        liste_pixels_ordonnes_par_ordre_croissant[k] = liste_pixels[indice];
                        liste_pixels[indice] = infini;
                    }
                    mediane = liste_pixels_ordonnes_par_ordre_croissant[(((dimension*dimension)-1)/2) -1];
                    ip.set(w, h, mediane);
                }
            }
        }
        ImagePlus imaf = originalImage.duplicate();
        imaf.setProcessor(ip);
        ImageIcon i2= new ImageIcon( imaf.getImage()) ;
        //originalImage.show();
        filtre_medien_label2.setIcon(i2);
    }
    
    public ImageProcessor segmentationSeuillage( ImageProcessor ip0, int width , int height )
    {
        ImageProcessor ip = ip0.duplicate();
        
        for ( int w = 0 ; w< width ; w++)
        {
            for(int h =0 ; h< height ; h++)
            {
                if(ip0.get( w ,h) < seuil ) ip.set(w, h, 0);
                else  ip.set(w, h, 255);
            }
        }
        return ip;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        TNI dialog = new TNI(new javax.swing.JFrame(), true);
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TNI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TNI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TNI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TNI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
        
        ConfigurationManager cm;

        if (args.length > 0) {
            cm = new ConfigurationManager(args[0]);
        } else {
            cm = new ConfigurationManager(TNI.class.getResource("new.xml"));
        }

        Recognizer recognizer = (Recognizer) cm.lookup("recognizer");
        recognizer.allocate();

        // start the microphone or exit if the programm if this is not possible
        Microphone microphone = (Microphone) cm.lookup("microphone");
        if (!microphone.startRecording()) {
            System.out.println("Cannot start microphone.");
            recognizer.deallocate();
            System.exit(1);
        }

        System.out.println("Say: Rotate ");

        // loop the recognition until the programm exits.
        while (true) {

            Result result = recognizer.recognize();

            if (result != null) {
                String resultText = result.getBestFinalResultNoFiller();
                System.out.println("You said: " + resultText + '\n');
                if(resultText.equals("rotate")) dialog.rotate();
                else if(resultText.equals("function one")) dialog.seuillageLaplacien();
                
                
                /*else if(resultText.equals("function one")) dialog.seuillageLaplacien();
                else if(resultText.equals("function two")) dialog.segmentationSeuilllageSimple();
                else if(resultText.equals("function three")) dialog.segmentationSeuilllageAdaptatif();
                else if(resultText.equals("function for")) dialog.masqueSobelX();
                else if(resultText.equals("function five")) dialog.masqueSobelY();
                else if(resultText.equals("function six")) dialog.filtreMedian();
                else if(resultText.equals("function seven")) dialog.filtreMoyen();*/
                
               
            } else {
                System.out.println("I can't hear what you said.\n");
            }
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel filtre_medien_label2;
    private javax.swing.JLabel filtre_moyen_label2;
    private javax.swing.JLabel garbor_filter_label2;
    private javax.swing.JLabel gradiant2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JSpinner jSpinner2;
    private javax.swing.JSpinner jSpinner3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel laplacien2;
    private javax.swing.JTextField rotate_image_name;
    private javax.swing.JPanel rotate_label1;
    private javax.swing.JPanel rotate_label2;
    private javax.swing.JLabel rotation_label1;
    private javax.swing.JLabel rotation_label2;
    private javax.swing.JScrollPane rotion_panel2;
    private javax.swing.JLabel seg_seuillage2;
    private javax.swing.JSpinner seuilSpinner;
    private javax.swing.JButton sobel_x;
    private javax.swing.JButton sobel_y;
    // End of variables declaration//GEN-END:variables
}
